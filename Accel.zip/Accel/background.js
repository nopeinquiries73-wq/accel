// Accel — background service worker.
// Currently idle; all logic lives in popup.js, which injects accel.js
// into the active tab on demand via chrome.scripting.executeScript.

chrome.runtime.onInstalled.addListener(() => {
  console.log("[Accel] extension installed.");
});
