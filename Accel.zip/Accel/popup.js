const dropdownToggle = document.getElementById("dropdownToggle");
const caret = document.getElementById("caret");
const menu = document.getElementById("menu");
const injectBtn = document.getElementById("injectBtn");
const statusEl = document.getElementById("status");
const footerEl = document.getElementById("footer");
const versionBadge = document.getElementById("versionBadge");

// The raw GitHub URL for the code that gets injected.
// Edit this to point at your own repo/file.
const SOURCE_URL = "https://raw.githubusercontent.com/nopeinquiries73-wq/accel/refs/heads/main/accel.js";

// The raw GitHub URL for a plain-text version string, e.g. a version.txt
// file in the same repo containing just "2.4.1" (or "v2.4.1").
const VERSION_URL = "https://raw.githubusercontent.com/nopeinquiries73-wq/accel/refs/heads/main/version.txt";

// Fallback shown if the version fetch fails (no network, 404, etc).
const FALLBACK_VERSION = "0.0.0";

function shortenUrl(url) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split("/").filter(Boolean);
    return parts.length ? parts[parts.length - 1] : u.hostname;
  } catch {
    return url;
  }
}

footerEl.textContent = "ACCEL · fetches " + shortenUrl(SOURCE_URL);
footerEl.title = SOURCE_URL;

async function loadVersion() {
  try {
    const bustUrl = VERSION_URL + (VERSION_URL.includes("?") ? "&" : "?") + "t=" + Date.now();
    const res = await fetch(bustUrl, { cache: "no-store" });
    if (!res.ok) throw new Error(String(res.status));
    let v = (await res.text()).trim();
    if (!v) throw new Error("empty");
    if (!v.toLowerCase().startsWith("v")) v = "v" + v;
    versionBadge.textContent = v;
  } catch (err) {
    console.warn("[Accel] version fetch failed, using fallback:", err.message);
    versionBadge.textContent = "v" + FALLBACK_VERSION;
  }
}

loadVersion();

dropdownToggle.addEventListener("click", () => {
  menu.classList.toggle("open");
  caret.classList.toggle("open");
});

function setStatus(message, kind) {
  statusEl.innerHTML = `<span class="dot"></span><span>${message}</span>`;
  statusEl.className = "status" + (kind ? " " + kind : "");
}

injectBtn.addEventListener("click", async () => {
  setStatus("Fetching…", "pending");
  menu.classList.remove("open");
  caret.classList.remove("open");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.id) {
      setStatus("No active tab found.", "error");
      return;
    }

    if (tab.url && (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("about:"))) {
      setStatus("Can't inject into browser internal pages.", "error");
      return;
    }

    // Cache-bust so you always get the latest commit, not a stale cached copy.
    const bustUrl = SOURCE_URL + (SOURCE_URL.includes("?") ? "&" : "?") + "t=" + Date.now();

    const res = await fetch(bustUrl, { cache: "no-store" });
    if (!res.ok) {
      setStatus(`Fetch failed: ${res.status} ${res.statusText}`, "error");
      return;
    }
    const code = await res.text();

    if (!code || !code.trim()) {
      setStatus("Fetched file is empty.", "error");
      return;
    }

    setStatus("Injecting…", "pending");

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: (codeStr) => {
        const script = document.createElement("script");
        script.textContent = codeStr;
        (document.head || document.documentElement).appendChild(script);
        script.remove();
      },
      args: [code]
    });

    setStatus("Injected", "success");
  } catch (err) {
    console.error("Accel injection failed:", err);
    setStatus("Failed: " + err.message, "error");
  }
});
