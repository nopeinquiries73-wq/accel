# Accel

A tiny Chrome extension for injecting debug code into a page with one click.
The code isn't bundled locally — Accel **fetches it live from a GitHub raw
URL** every time you click Inject, so updating the injected script is just a
git push, no need to reload the extension.

## Install (unpacked, for development/debugging use)

1. Open `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder
5. The Accel icon will appear in your toolbar

## Set your source

Open `popup.js` and edit these two constants near the top:

```js
const SOURCE_URL  = "https://raw.githubusercontent.com/USERNAME/REPO/main/accel.js";
const VERSION_URL = "https://raw.githubusercontent.com/USERNAME/REPO/main/version.txt";
```

Both need to be **raw** file URLs (`raw.githubusercontent.com/...`), not the
normal `github.com/.../blob/...` page, or the fetch pulls down an HTML page
instead of your content.

- `SOURCE_URL` — the actual debug script that gets injected into the page.
- `VERSION_URL` — a plain-text file (e.g. `version.txt`) containing just a
  version number, like `2.5.0`. The popup fetches this fresh every time it
  opens and shows it as the badge next to ACCEL. If the fetch fails (no
  network, file missing, etc.), it falls back to `FALLBACK_VERSION` in
  `popup.js`.

After editing either constant, reload the extension in `chrome://extensions`.

## Use

1. Click the Accel toolbar icon
2. Click **Actions** → **Inject**
3. Accel fetches the current contents of `SOURCE_URL` (cache-busted, so it
   always grabs the latest commit, not a stale CDN copy) and injects it as a
   live `<script>` tag into the page — same execution context as pasting
   into the F12 console.

## Notes

- Requires the GitHub repo/file to be **public** — `fetch` from the
  extension can't authenticate to pull a private repo's raw content.
- `host_permissions: ["<all_urls>"]` lets the extension fetch cross-origin
  from `raw.githubusercontent.com` without hitting CORS issues.
- If a page has a strict Content Security Policy, script injection can be
  blocked even though the extension reports success — check the page's own
  console for CSP errors if the injected code doesn't seem to run.
- GitHub's raw CDN can take a minute or two to reflect a brand-new commit
  even with cache-busting on our end — if you just pushed, give it a moment.
