const dropdownToggle = document.getElementById("dropdownToggle");
const caret = document.getElementById("caret");
const menu = document.getElementById("menu");
const injectBtn = document.getElementById("injectBtn");
const statusEl = document.getElementById("status");

dropdownToggle.addEventListener("click", () => {
  menu.classList.toggle("open");
  caret.classList.toggle("open");
});

function setStatus(message, kind) {
  statusEl.innerHTML = `<span class="dot"></span><span>${message}</span>`;
  statusEl.className = "status" + (kind ? " " + kind : "");
}

injectBtn.addEventListener("click", async () => {
  setStatus("Injecting…", "pending");
  menu.classList.remove("open");
  caret.classList.remove("open");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.id) {
      setStatus("No active tab found.", "error");
      return;
    }

    if (tab.url && (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("about:"))) {
      setStatus("Can't inject into browser internal pages.", "error");
      return;
    }

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["accel.js"],
      world: "MAIN"
    });

    setStatus("Injected", "success");
  } catch (err) {
    console.error("Accel injection failed:", err);
    setStatus("Injection failed: " + err.message, "error");
  }
});
