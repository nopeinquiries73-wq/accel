# Accel

A tiny Chrome extension for injecting debug code into a page with one click.
Click the dropdown, click **Inject**, and whatever's in `accel.js` runs live
on the page — same execution context as pasting into the F12 console.

## Install (unpacked, for development/debugging use)

1. Open `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder
5. The Accel icon will appear in your toolbar

## Use

1. Click the Accel toolbar icon
2. Click **Actions** to open the dropdown
3. Click **Inject**
4. `accel.js` runs directly in the page's own JS context (it can see the
   page's `window`, any frameworks loaded like React/jQuery, etc.)

## Editing what gets injected

Your debug code lives in **`accel.js`**. Edit that file, then in
`chrome://extensions` click the refresh icon on the Accel card to pick up
your changes, reload the target page, and click Inject again.

## Notes

- Manifest V3, `chrome.scripting.executeScript` with `world: "MAIN"` — runs
  as if it were the page's own script, full access to page globals.
- Requires `activeTab` + `scripting` permissions — only touches the tab
  you're viewing when you click Inject.
- Won't work on internal browser pages (`chrome://`, `edge://`, etc.).
- If a page has a strict Content Security Policy, script injection can be
  blocked even though the extension reports success — check the page's
  own console for CSP errors if `accel.js` doesn't seem to run.
